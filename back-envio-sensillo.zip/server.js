import Fastify from 'fastify'
import rateLimit from '@fastify/rate-limit'
import { fetch } from 'undici'

const app = Fastify({
  logger: { transport: { target: 'pino-pretty' } },
  trustProxy: true
})

await app.register(rateLimit, {
  max: 20,
  timeWindow: 1000
})

const ENTRY_TOKEN = process.env.ENTRY_TOKEN || 'MI_TOKEN_SECRETO'

// Middleware de autenticación
app.addHook('onRequest', async (req, reply) => {
  if (req.url === '/health') return // deja libre /health

  const auth = req.headers['authorization']
  if (!auth || auth !== `Bearer ${ENTRY_TOKEN}`) {
    return reply.code(401).send({ error: 'UNAUTHORIZED' })
  }
})


app.get('/health', async () => ({ ok: true, ts: Date.now() }))

const phoneRegex = /^\+?[1-9]\d{7,14}$/
const WATI_URL = process.env.WATI_URL
const WATI_TOKEN = process.env.WATI_TOKEN
const CHANNEL_NUMBER = process.env.CHANNEL_NUMBER

app.post('/ingest', {
  schema: {
    body: {
      type: 'object',
      required: ['phone', 'authCode'],
      properties: {
        phone: { type: 'string' },
        authCode: { type: 'string', minLength: 4, maxLength: 16 }
      },
      additionalProperties: false
    }
  }
}, async (req, reply) => {
  const { phone, authCode } = req.body

  if (!phoneRegex.test(phone)) {
    return reply.code(400).send({ error: 'PHONE_INVALID' })
  }

  req.log.info({ phone, authCode }, 'Datos recibidos')

  // 🔁 Envío a WATI
  const payload = {
    template_name: 'codigo_de_verificacion',
    broadcast_name: 'codigo_de_verificacion',
    receivers: [
      {
        whatsappNumber: phone.replace(/^\+/, ''), // quitar "+"
        customParams: [{ name: '1', value: authCode }]
      }
    ],
    channel_number: CHANNEL_NUMBER
  }

  try {
    const res = await fetch(WATI_URL, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'Authorization': `Bearer ${WATI_TOKEN}`
      },
      body: JSON.stringify(payload)
    })

    const data = await res.json().catch(() => ({}))

    if (!res.ok) {
      req.log.error({ status: res.status, data }, 'Error al enviar a WATI')
      return reply.code(502).send({ error: 'WATI_ERROR', detail: data })
    }

    req.log.info({ data }, 'Mensaje enviado a WATI')
    return reply.code(200).send({ status: 'FORWARDED', data })

  } catch (err) {
    req.log.error(err, 'Fallo en fetch a WATI')
    return reply.code(500).send({ error: 'FETCH_FAILED' })
  }
})

const PORT = process.env.PORT || 8080
await app.listen({ port: Number(PORT), host: '0.0.0.0' })
  .then(() => app.log.info(`Relay API escuchando en ${PORT}`))
  .catch(err => { app.log.error(err); process.exit(1) })
